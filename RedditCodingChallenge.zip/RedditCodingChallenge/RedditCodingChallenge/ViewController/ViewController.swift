//
//  ViewController.swift
//  RedditCodingChallenge
//
//  Created by devabhakthuni nomith sai chandra on 7/26/19.
//  Copyright © 2019 devabhakthuni nomith sai chandra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

}

