//
//  HomeViewController.swift
//  RedditCodingChallenge
//
//  Created by devabhakthuni nomith sai chandra on 7/26/19.
//  Copyright © 2019 devabhakthuni nomith sai chandra. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    @IBOutlet weak var homeTableView: UITableView!
    private lazy var service = ServiceModel()
    
    private struct Attributes {
        static let customCellIdentifier = "RedditTableViewCell"
        static let viewTitle = NSLocalizedString("Reddit", comment: "View Controller Title")
        static let urlToLoad = "http://www.reddit.com/.json"
        static let secondUrlToLoad = "https://www.reddit.com/.json?after"
        static let placeHolderImage = NSLocalizedString("placeHolder", comment: "Placeholder Image")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = Attributes.viewTitle
        getDataFromURL(redditUrlString: Attributes.urlToLoad)
    }
    
    //Method to fetch data from API
    private func getDataFromURL(redditUrlString:String) {
        self.service.serviceCall(urlString: redditUrlString) { [weak self] (success) in
            if success {
                DispatchQueue.main.async { [weak self] in
                    self?.homeTableView.reloadData()
                }
            }
        }
    }
    
    // MARK: Scroll view Delegate Methods
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let height = scrollView.frame.size.height
        let contentYoffset = scrollView.contentOffset.y
        let distanceFromBottom = scrollView.contentSize.height - contentYoffset
        // User has scrolled to bottom of tableview
        if distanceFromBottom < height {
            /*New service call is made with Second Url, Once tableview has scrolled to bottom.
             This will be called all the times when the user scrolls to the bottom, so that the data from webservice gets appended below to achieve Infinite scrolling*/
             getDataFromURL(redditUrlString: Attributes.secondUrlToLoad)
        }
    }
    
    // MARK: TableView Delegate Methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.service.titleArray.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: Attributes.customCellIdentifier, for: indexPath) as? RedditTableViewCell {
            cell.titleLabel.text = self.service.titleArray[indexPath.row]
            if let image = URL(string: self.service.thumbnailImageArray[indexPath.row]) {
                cell.thumbnailImage.load(url: image)
                //Setting placeholder image if imageview image is nil
                if cell.thumbnailImage.image == nil {
                    cell.thumbnailImage?.image = UIImage.init(named: Attributes.placeHolderImage)
                }
            }
            return cell
        }
        return UITableViewCell()
    }
    
}

