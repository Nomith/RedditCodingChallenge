//
//  TableViewCell.swift
//  RedditCodingChallenge
//
//  Created by devabhakthuni nomith sai chandra on 7/26/19.
//  Copyright © 2019 devabhakthuni nomith sai chandra. All rights reserved.
//

import UIKit

class RedditTableViewCell: UITableViewCell {

    @IBOutlet weak var thumbnailImage: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        self.thumbnailImage.image = nil
        // Set cell to initial state here, reset or set values
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
