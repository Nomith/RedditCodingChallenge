//
//  Service.swift
//  RedditCodingChallenge
//
//  Created by devabhakthuni nomith sai chandra on 7/26/19.
//  Copyright © 2019 devabhakthuni nomith sai chandra. All rights reserved.
//

import Foundation

class ServiceModel: NSObject {
    
   internal var titleArray = [String]()
   internal var thumbnailImageArray = [String]()
    
    private struct Attributes {
        static let error = "error"
        static let data = "data"
        static let children = "children"
        static let title = "title"
        static let thumbnail = "thumbnail"
    }
    
   internal func serviceCall(urlString:String, complete: @escaping (Bool) ->  Void)  {
        guard let url = URL(string: urlString) else {
            return
        }
        //fetching the data from the url
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            if (error != nil) {
                print(Attributes.error)
            }
            guard let data = data else {
                return
            }
                if let jsonObj = try? JSONSerialization.jsonObject(with: data, options: .allowFragments) as? NSDictionary {
                    if let data = jsonObj?.value(forKey: Attributes.data) as? NSDictionary, let childrenArray = data.value(forKey: Attributes.children) as? NSArray {
                        for children in childrenArray {
                            if let dataDic = children as? NSDictionary, let finalData  = dataDic.value(forKey: Attributes.data) as? NSDictionary {
                                if let title = finalData.value(forKey: Attributes.title) as? String {
                                    self.titleArray.append(title)
                                    if let thumbnail = finalData.value(forKey: Attributes.thumbnail), let finalUrl = thumbnail as? String {
                                        self.thumbnailImageArray.append(finalUrl)
                                    }
                                }
                            }
                        }
                    }
                    complete(true)
             }            
        }.resume()
    }
}
